<section class="freviews">

		<div class="section white center">
			<h3 class="header">Ce spun clientii nostri despre noi</h3>
			<div class="carousel myreviews" style="margin-bottom: 35px;">
			    <a class="carousel-item" href="#one!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me!"<br>-<br> <strong>Mike</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#two!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"Superb! Voi mai comanda cu siguranta!"<br>-<br> <strong>Andreea</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#three!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"Raport calitate pret exceptional!"<br>-<br> <strong>Sebastian</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#four!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"Nu credeam ca voi gasi mancare italiana asa buna in Romania"<br>-<br> <strong>Mihai</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#five!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"It's like how my grandma used to made me in the childhood"<br>-<br> <strong>Luca</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#six!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"Grozava mancarea!"<br>-<br> <strong>Jasmine</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#seven!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #ee6e73 !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me! Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Roy</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			  </div>
		</div>
	</section>