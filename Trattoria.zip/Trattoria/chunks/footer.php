<section class="ffooter">
		<footer class="page-footer">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Contact US</h5>
                <p class="grey-text text-lighten-4">Jud Timis, Oras Recas, strada Calea Timisoarei, nr. 84</p>
                <p class="grey-text text-lighten-4">Telefon: 0770 218 686</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Ne gasiti si pe:</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Facebook</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Instagram</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Twitter</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Whatsapp</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2023 Copyright @ Trattoria
            <a class="grey-text text-lighten-4 right" href="#!">Made in Italia with <span><i class="tiny material-icons">favorite</i></span></a>
            </div>
          </div>
        </footer>
	</section>