<section class="fdes">
		<div class="section white center">
			<h2 class="header" style="padding:20px; padding-bottom: 30px;">Pasiunea pentru bucatarie ne-a adus impreuna</h2>
		      <div class="row container center">
		        <div class="col center l8 s12">
		        	
				<p>
					Amintiri din Bucătărie:
Pentru mulți dintre membrii noștri, dragostea pentru gătit s-a născut în bucătăria familiei. De la mame și bunici grijulii am învățat secretele rețetelor tradiționale, iar aromele copilăriei ne-au inspirat să aducem aceeași căldură și autenticitate în farfuriile dumneavoastră. În fiecare mâncare pe care o pregătim, se regăsește o bucată din acele amintiri dragi.
</p>
<p>
De la Pasiune la Profesionalism:
Povestea noastră culinară a evoluat pe măsură ce am transformat pasiunea într-o carieră. Unii dintre membrii echipei noastre și-au dezvoltat talentele în bucătării de renume, au experimentat cu arome internaționale și au adus înapoi această diversitate în arta gătitului de la Trattoria.
</p>
<p>
Exploratori ai Aromelor Italiene:
Pentru alții, pasiunea pentru gătit a înflorit în timpul călătoriilor în Italia. Descoperirea bogăției regionale și autenticității fiecărui ingredient a fost o experiență transformătoare. Astfel, am adus la Trattoria această explorare continuă a aromelor italiene, prezentându-vă cele mai bune ingrediente în preparatele noastre autentice.
</p>
<p>
Creativitate la Fiecare Farfurie:
La Trattoria, gătitul este o formă de artă. Fiecare ingredient este ales cu grijă, fiecare rețetă este o creație originală, iar fiecare farfurie reprezintă o poveste de dragoste pentru gătit. Ne bucurăm să împărtășim această creativitate cu dumneavoastră, invitându-vă la o călătorie culinară autentică.
</p>
<p>
Comunitatea Trattoria:
Suntem o comunitate de pasionați de gătit, gata să vă aducem cele mai bune gusturi ale Italiei. La Trattoria, nu doar gătim, ci și împărtășim bucuria și pasiunea noastră pentru a crea amintiri de neuitat în jurul mesei.
					</p>
			</div>
		        <div class="col center l4 s12">
		        	<img height="300" width="auto" style="object-fit: contain;" src="images/17964.jpg" alt="">
		        </div>
		        
		      </div>
	</section>