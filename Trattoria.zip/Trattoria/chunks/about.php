<section class="fabout">
		<div class="section white center">
		      <div class="row container">
		        <h2 class="header">Despre noi</h2>
		        <p class="grey-text text-darken-3 lighten-3">
				La Trattoria, aducem o experiență culinară unică și autentică, unde gustul și eleganța se întâlnesc pentru a crea momente de neuitat. Suntem dedicați să oferim clienților noștri nu doar o masă, ci o călătorie gastronomică care să stârnească simțurile și să satisfacă cele mai pretențioase gusturi.

				Bucătăria noastră este pregătită cu pasiune și talent de către bucătari cu experiență, care selectează cu grijă cele mai proaspete ingrediente pentru a crea feluri de mâncare delicioase și inovatoare. De la preparate tradiționale la opțiuni internaționale, meniul nostru diversificat se potrivește gusturilor fiecărui oaspete.

				Cu o atmosferă caldă și primitoare, Trattoria este locul perfect pentru întâlniri romantice, cine de afaceri sau evenimente speciale. Decorul nostru elegant se îmbină cu servicii impecabile pentru a oferi o experiență de neegalat în lumea culinară.

				Descoperă selecția noastră vastă de băuturi fine, de la vinuri alese cu grijă la cocktail-uri creative pregătite de bărciști pricepuți. Oferim opțiuni pentru a satisface orice preferință și pentru a completa perfect fiecare masă.

				</p>
			<a href="/RestroGirls/about-restro-girls.php" class="waves-effect waves-light btn" style="background: #ee6e73 !important;">Read More &raquo;</a>
		</div>
	</section>