<section class="fabout">
		<div class="section white center">
		      <div class="row container">
		        <h2 class="header">ABOUT US</h2>
		        <p class="grey-text text-darken-3 lighten-3">
				Bine ați venit la Trattoria, un loc unde pasiunea pentru autenticitate și dragostea pentru gastronomia italiană se îmbină pentru a crea o experiență culinară de neuitat. Cu o istorie bogată și o bucată de Italia în inima noastră, suntem mândri să aducem un strop autentic de la Mama Italiei în fiecare farfurie.</p>
<p>
Despre Noi:
Trattoria  este mai mult decât un simplu restaurant; este o destinație gastronomică unde oaspeții noștri sunt invitați să se bucure de aromele, gusturile și atmosfera caldă a Italiei. Fondat cu pasiune pentru bucătăria tradițională italiană, restaurantul nostru este un omagiu adus ingredientelor proaspete, preparatelor casnice și ospitalității autentice italiene.
</p>
<p>
Bucătăria Noastră:
Bucătarii noștri talentați aduc la viață autenticitatea fiecărui fel de mâncare pregătit. De la paste proaspete făcute manual la pizza cu aluat subțire și arome intense, fiecare preparat reflectă bogăția culinară a diferitelor regiuni ale Italiei. Ingrediente premium și rețete tradiționale sunt ingredientele noastre secrete pentru a vă oferi o experiență autentică de gust.
</p>
<p>
Ambianță și Design:
Intră în atmosfera primitoare și caldă a Trattoriei , unde decorul nostru rafinat și elementele de design evocă farmecul țării noastre de origine. Fie că alegeți să luați masa într-un interior elegant sau pe terasa noastră primitoare, vă veți simți ca și cum ați fi în mijlocul unei călătorii prin pitorescul peisaj italian.
</p>
<p>
Meniu Diversificat:
Cu un meniu bogat și diversificat, veți găsi o varietate de preparate delicioase care să satisfacă orice poftă. De la antipasti rafinate la risotto cremos, fructe de mare proaspete și deserturi decadente, meniul nostru este o călătorie gastronomică prin regiunile cele mai cunoscute ale Italiei.
</p>
<p>
Vinuri Selecționate:
Completează experiența ta culinară cu o selecție aleasă de vinuri italiene. Consultă cu plăcere echipa noastră de somelieri pasionați pentru a găsi combinația perfectă care să sublinieze aromele fiecărui preparat.
</p>
<p>
Evenimente Speciale:
Trattoria este locul ideal pentru a sărbători momente speciale. Găzduim cu bucurie evenimente private, aniversări și cine romantice, oferind un serviciu personalizat și meniuri adaptate la preferințele tale.
</p>
<p>
Vizitează-ne la Trattoria și lasă-te purtat într-o călătorie culinară autentic italiană. Îți promitem că vei pleca cu inima plină și cu papilele gustative încântate!
</p>

				</p>
		      </div>
	</section>